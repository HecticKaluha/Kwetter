package exceptions;

public class ParametersWereEmptyException extends Exception
{
    public ParametersWereEmptyException(String message) {
        super(message);
    }
}

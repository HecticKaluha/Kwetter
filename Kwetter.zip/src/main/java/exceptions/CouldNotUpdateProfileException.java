package exceptions;

public class CouldNotUpdateProfileException extends Exception {
    public CouldNotUpdateProfileException(String message) {
        super(message);
    }
}

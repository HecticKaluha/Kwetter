package exceptions;

public class CouldNotGetLatestKweets extends Exception
{
    public CouldNotGetLatestKweets(String message) {
        super(message);
    }
}

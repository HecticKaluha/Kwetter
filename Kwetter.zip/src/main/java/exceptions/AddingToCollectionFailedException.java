package exceptions;

public class AddingToCollectionFailedException extends Exception
{
    public AddingToCollectionFailedException(String message) {
        super(message);
    }
}

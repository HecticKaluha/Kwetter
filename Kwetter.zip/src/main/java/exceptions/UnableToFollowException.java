package exceptions;

public class UnableToFollowException extends Exception
{
    public UnableToFollowException(String message) {
        super(message);
    }
}

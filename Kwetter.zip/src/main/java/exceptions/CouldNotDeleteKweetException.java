package exceptions;

public class CouldNotDeleteKweetException extends Exception
{
    public CouldNotDeleteKweetException(String message) {
        super(message);
    }
}

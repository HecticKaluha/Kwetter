package exceptions;

public class CouldNotFindProfileException extends Exception
{
    public CouldNotFindProfileException(String message)
    {
        super(message);
    }
}

package exceptions;

public class NoContentToUpdateException extends Exception
{
    public NoContentToUpdateException(String message)
    {
        super(message);
    }
}

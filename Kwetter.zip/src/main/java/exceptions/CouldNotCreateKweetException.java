package exceptions;

public class CouldNotCreateKweetException extends Exception
{
    public CouldNotCreateKweetException(String message) {
        super(message);
    }
}

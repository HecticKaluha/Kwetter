package exceptions;

public class AddigToDatabaseFailedException extends Exception
{
    public AddigToDatabaseFailedException(String message) {
        super(message);
    }
}

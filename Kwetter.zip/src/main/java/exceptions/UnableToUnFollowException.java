package exceptions;

public class UnableToUnFollowException extends Exception {
    public UnableToUnFollowException(String message) {
        super(message);
    }
}

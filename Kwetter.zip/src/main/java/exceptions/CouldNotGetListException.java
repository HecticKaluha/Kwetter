package exceptions;

public class CouldNotGetListException extends Exception
{
    public CouldNotGetListException(String message) {
        super(message);
    }
}

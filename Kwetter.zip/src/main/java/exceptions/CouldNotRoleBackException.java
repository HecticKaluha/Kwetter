package exceptions;

public class CouldNotRoleBackException extends Exception
{
    public CouldNotRoleBackException(String message) {
        super(message);
    }
}
